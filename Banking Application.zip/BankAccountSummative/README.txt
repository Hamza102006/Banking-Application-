When using this without a JAR FILE, program must be run through the SignInFrame java class, not any other CLASS.

Process of Main Program Functionality: SignInFrame -> UserHomeMenu

Rest of the classes are classes that either help with functionality of bank account, or frames that pop up 
after particular button has been hit.


IMPORTANT TEXT FILES THAT MUST NOT BE DELETED:
CustomerList.txt -> holds all current account customer object related information
InfoList.txt -> holds all current account chequing and saving object related information

Group Member Assigned Responsibilities:
	Rudra: Main UML Coordinator, Customer.java, Register_Login.java, Register_Info.java, Register_Balance.java, TransactionList.java, Resetting_ForgotPassword.java
	
	Thanush: Account.java, Chequing.java, Savings.java, UserHomeMenu.java, SignInFrame.java, TransactionList.java, TransactionRecord.java, UniversalMethods.java,
			 Money_Transfer.java, Register_Balance.java
			 
	Hamza: Gantt Project Manager, AboutUs_Frame.java, Currency_Exchange.java, FindUser_ForgotPassword.java, HomeMenu_Help.java,
	Money_Transfer.java, ProfileInfo_Button.java, Register_Balance.java, Register_Info.java, Register_Login.java, Resetting_ForgotPassword.java, 
	SignIn_Help.java,SignInFrame.java, UserHomeMenu.java


